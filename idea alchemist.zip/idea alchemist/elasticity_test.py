import random
import uuid
from locust import HttpUser, task, between

class IdeaAlchemistUser(HttpUser):
    """Elasticity test user for the Idea Alchemist Agent."""

    wait_time = between(1, 3)  # Faster requests to trigger scaling

    def on_start(self):
        """Set up user session when starting."""
        self.user_id = f"user_{uuid.uuid4()}"
        self.session_id = f"session_{uuid.uuid4()}"

        # Create session for the Idea Alchemist agent using proper ADK API format
        session_data = {"state": {"user_type": "elasticity_test_user"}}

        self.client.post(
            f"/apps/idea_alchemist_agent/users/{self.user_id}/sessions/{self.session_id}",
            headers={"Content-Type": "application/json"},
            json=session_data,
        )

    @task(4)
    def test_conversations(self):
        """Test conversational capabilities - high frequency."""
        topics = [
            "Give me a futuristic product idea using AI and coffee.",
            "Mix gaming and meditation—what startup could that be?",
            "Invent a futuristic pencil powered by emotions.",
            "Create business ideas that combine drones and pets.",
            "Give me 3 chaotic startup ideas involving teleportation.",
            "Turn the concept of 'alarm clock' into a disruptive invention."
        ]

        # Proper ADK message format
        message_data = {
            "app_name": "idea_alchemist_agent",
            "user_id": self.user_id,
            "session_id": self.session_id,
            "new_message": {
                "role": "user",
                "parts": [{
                    "text": random.choice(topics)
                }]
            }
        }

        self.client.post(
            "/run",
            headers={"Content-Type": "application/json"},
            json=message_data,
        )

    @task(1)
    def health_check(self):
        """Test the health endpoint."""
        self.client.get("/health")
